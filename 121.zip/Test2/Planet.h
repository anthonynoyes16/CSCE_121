#include <iostream>
#include <string>
#include <sstream>


using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::string;

class Planet {
    private:
        string name;
        double distanceFromSun;
        bool isGaseous;
    public:
        Planet(string name, double distanceFromSun, bool isGaseous);
        string getName();
        double getDistanceFromSun();
        bool getIsGaseous();
};