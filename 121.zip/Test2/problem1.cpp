#include "problem1.h"
#include <stdexcept>

using std::string;

void add_to_row(Row& row, const string& name) {
    if (row.capacity == row.size) {
        row.capacity *= 2;
    }
    row.array[row.size] = name;
    row.size += 1;
}

string remove_from_row (Row& row) {
    if (row.size == 0) {
        throw std::out_of_range("no ducks");
    }
    string hold = row.array[0];
    for (size_t i = 0; i < row.size; i++) {
        row.array[i] = row.array[i+1];
    }
    row.size -= 1;
    return hold;
}

Row split(Row& row) {
    Row new_row;
    for (size_t i = 0; i < row.size-2; i+=2) {
        new_row.array[i] = row.array[i+1];
        row.array[i+1] = row.array[i+2];
        row.size -= 1;
    }
    return new_row;
}