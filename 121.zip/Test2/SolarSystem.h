#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include "Planet.h"

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::string;
using std::vector;

class SolarSystem {
    private:
        string name;
        vector<Planet> planets;
    public:
        SolarSystem(string name);
        string getName();
        void addPlanet(Planet newPlanet);
};